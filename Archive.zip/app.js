const express = require('express');
const m3u8ToMp4 = require('m3u8-to-mp4');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const port = 3000;

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const tmpDir = path.join(__dirname, 'tmp');
const fileExpirationTime = 24 * 60 * 60 * 1000; // 24 hours in milliseconds

let convertedFiles = {}; // Store conversion status and file paths

// Ensure the tmp directory exists
if (!fs.existsSync(tmpDir)) {
  fs.mkdirSync(tmpDir, { recursive: true });
}

// Cleanup function to delete old files
function cleanupOldFiles() {
  const now = Date.now();
  fs.readdir(tmpDir, (err, files) => {
    if (err) {
      console.error('Error reading tmp directory:', err);
      return;
    }
    files.forEach(file => {
      const filePath = path.join(tmpDir, file);
      fs.stat(filePath, (err, stats) => {
        if (err) {
          console.error('Error getting file stats:', err);
          return;
        }
        if (now - stats.mtimeMs > fileExpirationTime) {
          fs.unlink(filePath, err => {
            if (err) {
              console.error('Error deleting file:', err);
            } else {
              console.log(`Deleted old file: ${filePath}`);
            }
          });
        }
      });
    });
  });
}

// Run cleanup every hour
setInterval(cleanupOldFiles, 60 * 60 * 1000); // 1 hour in milliseconds

app.get('/', (req, res) => {
  const url = req.query.url;
  if (!url) {
    return res.status(400).send('m3u8 URL is required');
  }

  const fileId = uuidv4();
  const filename = `${fileId}.mp4`;
  const outputPath = path.join(tmpDir, filename);

  convertedFiles[fileId] = { status: 'processing', filePath: outputPath };

  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>HLS to Video File by VidBinge</title>
      <script src="https://cdn.tailwindcss.com"></script>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body class="bg-gray-200 flex items-center justify-center min-h-screen">
      <div class="bg-white p-8 rounded-lg shadow-lg text-center">
        <h1 class="text-2xl text-pretty font-bold mb-4">HLS to Video Conversion powered by VidBinge</h1>
        <h2 class="text-xl font-bold mb-4">Conversion Progress</h2>
        <div class="flex w-full h-1.5 bg-gray-200 rounded-full overflow-hidden" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
          <div id="progress-bar" class="flex flex-col justify-center rounded-full overflow-hidden bg-blue-600 text-xs text-white text-center whitespace-nowrap transition duration-500" style="width: 0%"></div>
        </div>
        <div id="status" class="mt-2 text-lg">Starting...</div>
        <div id="download-link" class="mt-4 text-blue-500 hidden"><a href="/download?fileId=${fileId}" target="_blank">Download doesn't start automatically? Click here to download</a></div>
      </div>
      <script>
        const socket = new WebSocket('ws://' + window.location.host);
        socket.onmessage = function(event) {
          const message = JSON.parse(event.data);
          if (message.fileId === '${fileId}') {
            const progressBar = document.getElementById('progress-bar');
            const statusText = document.getElementById('status');
            const downloadLink = document.getElementById('download-link');
            const progressMatch = message.status.match(/(\\d+)%/);
            if (progressMatch) {
              const progress = progressMatch[1];
              progressBar.style.width = progress + '%';
              progressBar.setAttribute('aria-valuenow', progress);
            }
            if (message.status.includes('Conversion complete!')) {
              progressBar.style.width = '100%';
              progressBar.setAttribute('aria-valuenow', 100);
              statusText.innerText = 'Conversion complete! Starting download...';
              downloadLink.classList.remove('hidden');
              setTimeout(() => {
                window.location.href = '/download?fileId=${fileId}';
              }, 1000); // Give a short delay before starting download
            } else {
              statusText.innerText = message.status;
            }
          }
        };
      </script>
    </body>
    </html>
  `);

  const converter = new m3u8ToMp4();
  let interval;

  (async () => {
    try {
      let progress = 0;
      interval = setInterval(() => {
        progress += 10;
        if (progress >= 100) {
          clearInterval(interval);
        } else {
          broadcast({ fileId, status: `Conversion progress: ${progress}%` });
        }
      }, 3000); // Simulate progress updates every 3 seconds

      await converter
        .setInputFile(url)
        .setOutputFile(outputPath)
        .start();

      clearInterval(interval);
      convertedFiles[fileId].status = 'Conversion complete! Starting download...';
      broadcast({ fileId, status: 'Conversion complete! Starting download...' });

      console.log(`File converted: ${filename}`);
    } catch (error) {
      if (interval) {
        clearInterval(interval);
      }
      console.error('Error converting file:', error);
      convertedFiles[fileId].status = 'Error converting file';
      broadcast({ fileId, status: 'Error converting file' });
    }
  })();
});

app.get('/download', (req, res) => {
  const fileId = req.query.fileId;
  if (!fileId || !convertedFiles[fileId]) {
    return res.status(400).send('Invalid file ID. File likely already downloaded. Please check your Downloads.');
  }

  const { filePath } = convertedFiles[fileId];

  res.download(filePath, (err) => {
    if (err) {
      console.error('Error sending file:', err);
    }
    // Do not delete the file after download
  });
});

function broadcast(data) {
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(data));
    }
  });
}

server.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
